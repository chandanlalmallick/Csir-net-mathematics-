/* =========================================================================
   SCOREBOOSTER — CSIR-NET MATHEMATICAL SCIENCES MOCK TEST ENGINE
   Pure vanilla JS. No dependencies. No build step.
   ========================================================================= */

/* --------------------------- CONFIG --------------------------- */
const TOTAL_TESTS = 5;
const TEST_DURATION_SEC = 180 * 60;

const PART_CONFIG = {
  A: { count: 20, maxAttempt: 15, correct: 2,    wrong: -0.5,  negative: true  },
  B: { count: 40, maxAttempt: 25, correct: 3,    wrong: -0.75, negative: true  },
  C: { count: 60, maxAttempt: 20, correct: 4.75, wrong: 0,     negative: false }
};

const TEST_META = [
  { id: 1, label: "MOCK TEST 1", difficultyTag: "STANDARD",      seedBase: 101, mix: { easy: .45, moderate: .40, hard: .12, veryhard: .03 } },
  { id: 2, label: "MOCK TEST 2", difficultyTag: "STANDARD+",     seedBase: 202, mix: { easy: .35, moderate: .43, hard: .17, veryhard: .05 } },
  { id: 3, label: "MOCK TEST 3", difficultyTag: "DIFFICULT",     seedBase: 303, mix: { easy: .25, moderate: .40, hard: .25, veryhard: .10 } },
  { id: 4, label: "MOCK TEST 4", difficultyTag: "VERY DIFFICULT",seedBase: 404, mix: { easy: .15, moderate: .35, hard: .30, veryhard: .20 } },
  { id: 5, label: "MOCK TEST 5", difficultyTag: "ADVANCED",      seedBase: 505, mix: { easy: .08, moderate: .27, hard: .35, veryhard: .30 } }
];

// Topic weights for Part B + Part C combined (approximate target %, per spec).
const TOPIC_WEIGHTS = {
  "Real Analysis": 16.5, "Linear Algebra": 13.5, "Complex Analysis": 11,
  "Abstract Algebra": 11, "ODE": 8, "PDE": 6, "Probability": 6,
  "Statistics": 5, "Numerical Analysis": 5, "Topology": 4,
  "Functional Analysis": 4, "Number Theory": 3, "Calculus": 3, "Discrete Mathematics": 3
};

const TOPIC_LIST = Object.keys(TOPIC_WEIGHTS);

/* --------------------------- SEEDED RNG --------------------------- */
// Mulberry32 - deterministic per test (papers vary by test id and attempt number)
function makeRNG(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function rInt(rng, min, max) { return Math.floor(rng() * (max - min + 1)) + min; }
function rPick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
function rSign(rng) { return rng() < 0.5 ? -1 : 1; }
function shuffle(rng, arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function fmtNum(x) {
  if (Number.isInteger(x)) return String(x);
  return (Math.round(x * 1000) / 1000).toString();
}
function fracStr(num, den) {
  if (den < 0) { num = -num; den = -den; }
  const g = gcd(Math.abs(num), Math.abs(den)) || 1;
  num /= g; den /= g;
  if (den === 1) return String(num);
  return `${num}/${den}`;
}
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a; }

/* --------------------------- MATH HELPERS --------------------------- */
function det2(m) { return m[0][0] * m[1][1] - m[0][1] * m[1][0]; }
function det3(m) {
  return (
    m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
    m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
    m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
  );
}
function matRankInt(matrix) {
  // Gaussian elimination with fractions, on a copy
  const m = matrix.map(r => r.slice().map(Number));
  const rows = m.length, cols = m[0].length;
  let rank = 0;
  for (let col = 0; col < cols && rank < rows; col++) {
    let pivot = -1;
    for (let r = rank; r < rows; r++) if (Math.abs(m[r][col]) > 1e-9) { pivot = r; break; }
    if (pivot === -1) continue;
    [m[rank], m[pivot]] = [m[pivot], m[rank]];
    for (let r = 0; r < rows; r++) {
      if (r !== rank) {
        const factor = m[r][col] / m[rank][col];
        for (let c = col; c < cols; c++) m[r][c] -= factor * m[rank][c];
      }
    }
    rank++;
  }
  return rank;
}
function eigen2x2Integer(rng) {
  // Build a 2x2 integer matrix with guaranteed real integer eigenvalues l1,l2.
  const l1 = rInt(rng, -4, 5), l2 = rInt(rng, -4, 5);
  // similarity transform with integer unimodular P = [[1,k],[0,1]] type to mix off-diagonal
  const k = rInt(rng, 1, 2);
  // D = diag(l1,l2); A = P D P^-1 with P=[[1,k],[0,1]] => P^-1=[[1,-k],[0,1]]
  const a = l1, b = k * (l2 - l1), c = 0, d = l2;
  return { matrix: [[a, b], [c, d]], eigenvalues: [l1, l2] };
}
function polyDerivative(coeffs) {
  // coeffs highest degree first, e.g. [1,-3,2] = x^2-3x+2
  const n = coeffs.length - 1;
  return coeffs.slice(0, n).map((c, i) => c * (n - i));
}
function evalPoly(coeffs, x) {
  return coeffs.reduce((acc, c) => acc * x + c, 0);
}

/* --------------------------- FINGERPRINT DEDUP --------------------------- */
const FP_KEY = "scorebooster_fingerprints";
function loadFingerprints() {
  try { return new Set(JSON.parse(localStorage.getItem(FP_KEY) || "[]")); }
  catch (e) { return new Set(); }
}
function saveFingerprints(set) {
  const arr = Array.from(set);
  // cap growth to keep localStorage lean
  const trimmed = arr.length > 4000 ? arr.slice(arr.length - 4000) : arr;
  localStorage.setItem(FP_KEY, JSON.stringify(trimmed));
}
let usedFingerprints = loadFingerprints();

/* =========================================================================
   QUESTION GENERATORS
   Each returns: { topic, part, difficulty, question, options[4], correct:[idx...],
                   multiple:boolean, explanation, fp }
   ========================================================================= */

function makeMCQ({ topic, difficulty, question, correctText, wrongTexts, explanation, multiple, correctIdxSet }) {
  let options, correct;
  if (multiple) {
    options = wrongTexts; // full pre-built 4 options
    correct = correctIdxSet;
  } else {
    const wrongs = shuffle(Math.random, wrongTexts).slice(0, 3);
    const all = shuffle(Math.random, [correctText, ...wrongs]);
    options = all;
    correct = [all.indexOf(correctText)];
  }
  return { topic, difficulty, question, options, correct, multiple: !!multiple, explanation };
}

function fp(topic, key) { return topic + "::" + key; }

/* ---------- REAL ANALYSIS ---------- */
function genRealAnalysis(rng, difficulty) {
  const templates = [
    function seqLimit() {
      const c = rInt(rng, 2, 9);
      const q = `Evaluate: lim (n→∞) (1 + ${c}/n)^n`;
      const ans = `e^${c}`;
      const wrong = [`e^${c + 1}`, `${c}`, `1`, `∞`, `e^${Math.max(1, c - 1)}`];
      return { key: `seqlimit-${c}`, q, ans, wrong, exp: `By the standard limit lim(1+c/n)^n = e^c, here c = ${c}, so the limit is e^${c}.` };
    },
    function pSeries() {
      const p = (rInt(rng, 5, 30)) / 10; // 0.5 to 3.0
      const q = `The series Σ (1/n^${p}) for n=1 to ∞ is:`;
      const converges = p > 1;
      const ans = converges ? "Convergent" : "Divergent";
      const wrong = ["Convergent", "Divergent", "Oscillatory", "Conditionally convergent"].filter(x => x !== ans);
      return { key: `pseries-${p}`, q, ans, wrong, exp: `By the p-series test, Σ1/n^p converges iff p>1. Here p=${p}, so the series is ${ans.toLowerCase()}.` };
    },
    function uniformConv() {
      const a = (rInt(rng, 2, 8)) / 10;
      const q = `Consider f_n(x) = x^n on the interval [0, ${a}] where 0<${a}<1. The sequence (f_n) converges:`;
      const ans = "Uniformly to 0";
      const wrong = ["Uniformly to 1", "Pointwise but not uniformly to 0", "To a discontinuous limit", "Nowhere"];
      return { key: `unifconv-${a}`, q, ans, wrong, exp: `Since 0<${a}<1, sup|x^n - 0| = ${a}^n → 0, so convergence is uniform to the zero function on [0,${a}].` };
    },
    function mvt() {
      const a = rInt(rng, 1, 3), b = a + rInt(rng, 2, 4);
      const q = `For f(x) = x^2 on [${a}, ${b}], the point c guaranteed by the Mean Value Theorem satisfies f'(c) = (f(${b})-f(${a}))/(${b}-${a}). Find c.`;
      const c = (a + b) / 2;
      const ans = fracStr(a + b, 2);
      const wrong = [String(a), String(b), fracStr(a + b, 4), String(a + b)];
      return { key: `mvt-${a}-${b}`, q, ans, wrong, exp: `f'(x)=2x, and (f(b)-f(a))/(b-a) = a+b. Solving 2c=a+b gives c=(a+b)/2 = ${ans}.` };
    },
    function contCounterexample() {
      const q = `Which of the following functions is continuous everywhere on ℝ but NOT differentiable at x = 0?`;
      const ans = "f(x) = |x|";
      const wrong = ["f(x) = x^2", "f(x) = sin(x)", "f(x) = e^x", "f(x) = x^3"];
      return { key: `contcounter`, q, ans, wrong, exp: `|x| is continuous everywhere but has a corner at x=0, where the left and right derivatives (−1 and 1) disagree.` };
    },
    function compactSet() {
      const opts = ["[0,1]", "(0,1)", "ℝ", "[0,∞)"];
      const q = `Which of the following subsets of ℝ (with the usual metric) is compact?`;
      const ans = "[0,1]";
      const wrong = opts.filter(o => o !== ans);
      return { key: `compact`, q, ans, wrong, exp: `By Heine–Borel, a subset of ℝ is compact iff it is closed and bounded. Only [0,1] is both closed and bounded.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- LINEAR ALGEBRA ---------- */
function genLinearAlgebra(rng, difficulty) {
  const templates = [
    function determinant2x2() {
      const m = [[rInt(rng, -5, 5), rInt(rng, -5, 5)], [rInt(rng, -5, 5), rInt(rng, -5, 5)]];
      const d = det2(m);
      const q = `Find the determinant of the matrix [[${m[0][0]}, ${m[0][1]}], [${m[1][0]}, ${m[1][1]}]].`;
      const wrong = [d + 1, d - 1, -d, d + 2].map(String);
      return { key: `det2-${m.flat().join(",")}`, q, ans: String(d), wrong, exp: `det = (${m[0][0]})(${m[1][1]}) − (${m[0][1]})(${m[1][0]}) = ${d}.` };
    },
    function determinant3x3() {
      const m = [[rInt(rng, -3, 3), rInt(rng, -3, 3), rInt(rng, -3, 3)],
                 [rInt(rng, -3, 3), rInt(rng, -3, 3), rInt(rng, -3, 3)],
                 [0, rInt(rng, -3, 3), rInt(rng, -3, 3)]];
      const d = det3(m);
      const q = `Find the determinant of the 3×3 matrix with rows [${m[0].join(",")}], [${m[1].join(",")}], [${m[2].join(",")}].`;
      const wrong = [d + 1, d - 2, -d, d + 3].map(String);
      return { key: `det3-${m.flat().join(",")}`, q, ans: String(d), wrong, exp: `Expanding along the first row gives determinant = ${d}.` };
    },
    function rankMatrix() {
      const base = [[1, 2, 3], [2, 4, 6], [1, 0, rInt(rng, 1, 5)]];
      const r = matRankInt(base);
      const q = `Find the rank of the matrix with rows [1,2,3], [2,4,6], [1,0,${base[2][2]}].`;
      const wrong = [1, 2, 3].filter(x => x !== r).map(String);
      return { key: `rank-${base[2][2]}`, q, ans: String(r), wrong, exp: `Row 2 = 2×Row 1, so rows are dependent; the rank is determined by the remaining independent rows, giving rank = ${r}.` };
    },
    function eigenvalues2x2() {
      const { matrix, eigenvalues } = eigen2x2Integer(rng);
      const q = `Find the eigenvalues of the matrix [[${matrix[0][0]}, ${matrix[0][1]}], [${matrix[1][0]}, ${matrix[1][1]}]].`;
      const sorted = eigenvalues.slice().sort((a, b) => a - b);
      const ans = `${sorted[0]} and ${sorted[1]}`;
      const wrong = [
        `${sorted[0] + 1} and ${sorted[1]}`,
        `${sorted[0]} and ${sorted[1] + 1}`,
        `${-sorted[0]} and ${-sorted[1]}`,
        `${sorted[0] - 1} and ${sorted[1] - 1}`
      ];
      return { key: `eig2-${matrix.flat().join(",")}`, q, ans, wrong, exp: `The matrix is upper (or lower) triangular after the similarity construction, so its eigenvalues are the diagonal entries: ${matrix[0][0]} and ${matrix[1][1]}.` };
    },
    function traceDetProperty() {
      const l1 = rInt(rng, 1, 6), l2 = rInt(rng, 1, 6);
      const q = `A 2×2 matrix A has eigenvalues ${l1} and ${l2}. What is det(A) · [trace(A)]⁻¹ · (${l1}+${l2})? (Assume trace(A) ≠ 0.)`;
      const detA = l1 * l2, trace = l1 + l2;
      const val = (detA / trace) * trace; // = detA
      const ans = fmtNum(val);
      const wrong = [fmtNum(val + 1), fmtNum(val - 1), fmtNum(trace), fmtNum(l1 * l2 + 1)];
      return { key: `tracedet-${l1}-${l2}`, q, ans, wrong, exp: `det(A)=λ1λ2=${detA}, trace(A)=λ1+λ2=${trace}. So the expression simplifies to det(A) = ${detA}.` };
    },
    function vectorSpaceDim() {
      const n = rInt(rng, 3, 6);
      const q = `What is the dimension of the vector space of all n×n symmetric matrices over ℝ, for n = ${n}?`;
      const d = n * (n + 1) / 2;
      const wrong = [n * n, d + 1, d - 1, n * (n - 1) / 2].map(String);
      return { key: `symdim-${n}`, q, ans: String(d), wrong, exp: `The space of n×n symmetric matrices has dimension n(n+1)/2. For n=${n}, this is ${d}.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- COMPLEX ANALYSIS ---------- */
function genComplexAnalysis(rng, difficulty) {
  const templates = [
    function simplePoleResidue() {
      const a = rInt(rng, 1, 5) * rSign(rng);
      const q = `Find the residue of f(z) = 1/(z − ${a}) at its pole z = ${a}.`;
      const ans = "1";
      const wrong = ["0", "-1", String(a), "z"];
      return { key: `res-simple-${a}`, q, ans, wrong, exp: `For f(z) = 1/(z−a), the residue at the simple pole z=a is the coefficient 1.` };
    },
    function residueTwoFactors() {
      const a = rInt(rng, 1, 4), b = a + rInt(rng, 1, 4);
      const q = `Find the residue of f(z) = 1/[(z − ${a})(z − ${b})] at z = ${a}.`;
      const val = 1 / (a - b);
      const ans = fracStr(1, a - b);
      const wrong = [fracStr(1, b - a), fracStr(1, a + b), fracStr(-1, a - b), fracStr(2, a - b)];
      return { key: `res2-${a}-${b}`, q, ans, wrong, exp: `Res at z=${a} is lim(z→${a}) (z−${a})f(z) = 1/(${a}−${b}) = ${ans}.` };
    },
    function contourIntegral() {
      const a = rInt(rng, 1, 3);
      const q = `Evaluate ∮_C dz/(z − ${a}) where C is the circle |z| = ${a + 1} traversed counterclockwise.`;
      const ans = "2πi";
      const wrong = ["0", "πi", "4πi", "-2πi"];
      return { key: `contour-${a}`, q, ans, wrong, exp: `Since z=${a} lies inside |z|=${a + 1}, by Cauchy's Integral Formula the integral equals 2πi·Res = 2πi.` };
    },
    function cauchyRiemann() {
      const q = `Which pair of functions u(x,y), v(x,y) satisfies the Cauchy–Riemann equations, so that f = u+iv is analytic? (I) u=x²−y², v=2xy  (II) u=x²+y², v=2xy`;
      const ans = "Only (I)";
      const wrong = ["Only (II)", "Both (I) and (II)", "Neither", "Cannot be determined"];
      return { key: `cr-pair`, q, ans, wrong, exp: `For (I): u_x=2x=v_y, u_y=−2y=−v_x ✓ CR equations hold. For (II): u_x=2x but v_y=2x while u_y=2y and −v_x=−2y, which fails since u_y≠−v_x unless y=0. So only (I) is analytic.` };
    },
    function orderOfPole() {
      const n = rInt(rng, 2, 4);
      const a = rInt(rng, 1, 4);
      const q = `What is the order of the pole of f(z) = 1/(z − ${a})^${n} at z = ${a}?`;
      const wrong = [n + 1, n - 1 || 4, 1, 2 * n].map(String);
      return { key: `poleorder-${a}-${n}`, q, ans: String(n), wrong, exp: `f has a pole of order equal to the power in the denominator, which is ${n}.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- ABSTRACT ALGEBRA ---------- */
function genAbstractAlgebra(rng, difficulty) {
  const templates = [
    function orderElementZn() {
      const n = rPick(rng, [8, 10, 12, 15, 18, 20]);
      const a = rInt(rng, 1, n - 1);
      const order = n / gcd(n, a);
      const q = `In the group (ℤ_${n}, +), what is the order of the element ${a}?`;
      const wrong = [order + 1, Math.max(1, order - 1), n, gcd(n, a)].map(String);
      return { key: `ordzn-${n}-${a}`, q, ans: String(order), wrong, exp: `The order of a in ℤ_n is n/gcd(n,a). Here n=${n}, gcd(${n},${a})=${gcd(n, a)}, so the order is ${order}.` };
    },
    function lagrangeDivisor() {
      const n = rPick(rng, [12, 18, 20, 24, 30]);
      const divisors = [];
      for (let i = 1; i <= n; i++) if (n % i === 0) divisors.push(i);
      const notDivisor = [5, 7, 8, 9, 11, 13, 16].find(x => n % x !== 0) || (n + 1);
      const q = `By Lagrange's Theorem, which of the following CANNOT be the order of a subgroup of a group of order ${n}?`;
      const ans = String(notDivisor);
      const wrong = shuffle(rng, divisors.filter(d => d !== n)).slice(0, 3).map(String);
      return { key: `lagrange-${n}`, q, ans, wrong, exp: `By Lagrange's theorem, the order of any subgroup must divide the group order. Since ${notDivisor} does not divide ${n}, it cannot be a subgroup order.` };
    },
    function eulerPhiGenerators() {
      const n = rPick(rng, [8, 10, 12, 15, 20, 24]);
      let phi = 0;
      for (let k = 1; k <= n; k++) if (gcd(k, n) === 1) phi++;
      const q = `How many generators does the cyclic group ℤ_${n} have?`;
      const wrong = [phi + 1, Math.max(1, phi - 1), n / 2, n - 1].map(String);
      return { key: `phi-${n}`, q, ans: String(phi), wrong, exp: `The number of generators of ℤ_n equals φ(n) (Euler's totient). φ(${n}) = ${phi}.` };
    },
    function quotientGroupOrder() {
      const n = rPick(rng, [12, 18, 24, 30, 36]);
      const divisors = []; for (let i = 1; i <= n; i++) if (n % i === 0) divisors.push(i);
      const h = rPick(rng, divisors.filter(d => d !== n && d !== 1));
      const q = `If G is a group of order ${n} and H is a normal subgroup of order ${h}, what is the order of G/H?`;
      const ans = String(n / h);
      const wrong = [n / h + 1, h, n, Math.max(1, n / h - 1)].map(String);
      return { key: `quotient-${n}-${h}`, q, ans, wrong, exp: `|G/H| = |G|/|H| = ${n}/${h} = ${n / h}.` };
    },
    function homomorphismKernel() {
      const q = `Let φ: G → H be a group homomorphism. Which statement is always TRUE?`;
      const ans = "ker(φ) is a normal subgroup of G";
      const wrong = ["ker(φ) is always trivial", "im(φ) is always all of H", "φ is always injective", "ker(φ) need not be a subgroup"];
      return { key: `homkernel`, q, ans, wrong, exp: `The kernel of any group homomorphism is always a normal subgroup of the domain — this is a standard consequence of the First Isomorphism Theorem.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- ODE ---------- */
function genODE(rng, difficulty) {
  const templates = [
    function charRoots() {
      const r1 = rInt(rng, -4, 4), r2 = rInt(rng, -4, 4);
      const b = -(r1 + r2), c = r1 * r2;
      const q = `The general solution of y'' ${b >= 0 ? '+' : '−'} ${Math.abs(b)}y' ${c >= 0 ? '+' : '−'} ${Math.abs(c)}y = 0 has characteristic roots r1, r2. If r1=${r1}, what is r2?`;
      const wrong = [r2 + 1, r2 - 1, -r2, r1].filter(x => x !== r2).map(String).slice(0, 3);
      while (wrong.length < 3) wrong.push(String(r2 + wrong.length + 2));
      return { key: `charroots-${r1}-${r2}`, q, ans: String(r2), wrong, exp: `Characteristic equation r² ${b >= 0 ? '+' : '−'} ${Math.abs(b)}r ${c >= 0 ? '+' : '−'} ${Math.abs(c)} = 0 factors as (r−${r1})(r−${r2})=0, giving roots ${r1} and ${r2}.` };
    },
    function firstOrderLinear() {
      const k = rInt(rng, 1, 5);
      const q = `Solve dy/dx + ${k}y = 0, given y(0) = 1. What is y(x)?`;
      const ans = `e^(−${k}x)`;
      const wrong = [`e^(${k}x)`, `e^(−${k}x²)`, `${k}e^(−x)`, `−e^(${k}x)`];
      return { key: `firstorder-${k}`, q, ans, wrong, exp: `This is separable: dy/y = −${k}dx, giving ln y = −${k}x + C. With y(0)=1, C=0, so y = e^(−${k}x).` };
    },
    function orderOfODE() {
      const n = rInt(rng, 2, 4);
      const q = `What is the order of the differential equation (d^${n}y/dx^${n}) + 3(dy/dx)² − y = sin(x)?`;
      const wrong = [n + 1, Math.max(1, n - 1), 2 * n, 1].map(String);
      return { key: `odeorder-${n}`, q, ans: String(n), wrong, exp: `The order of an ODE is the order of the highest derivative present, which is ${n}.` };
    },
    function eulerEquidim() {
      const q = `An equation of the form x²y'' + axy' + by = 0 (a, b constants) is called:`;
      const ans = "Euler (equidimensional) equation";
      const wrong = ["Bernoulli equation", "Exact equation", "Riccati equation", "Clairaut equation"];
      return { key: `euler-eq`, q, ans, wrong, exp: `This form, with variable coefficients x² and x matching the derivative order, defines the Euler (Cauchy–Euler / equidimensional) equation, solved via the substitution x = e^t.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- PDE ---------- */
function genPDE(rng, difficulty) {
  const templates = [
    function classifyPDE() {
      const A = rInt(rng, 1, 4), C = rInt(rng, 1, 4);
      const B = rPick(rng, [0, 2 * Math.round(Math.sqrt(A * C)), 2 * Math.round(Math.sqrt(A * C)) + 4, 1]);
      const disc = B * B - 4 * A * C;
      const type = disc < 0 ? "Elliptic" : disc === 0 ? "Parabolic" : "Hyperbolic";
      const q = `Classify the PDE: ${A}u_xx + ${B}u_xy + ${C}u_yy = 0 using the discriminant B² − 4AC.`;
      const wrong = ["Elliptic", "Parabolic", "Hyperbolic"].filter(t => t !== type);
      return { key: `classify-${A}-${B}-${C}`, q, ans: type, wrong, exp: `Here A=${A}, B=${B}, C=${C}, so B²−4AC = ${disc}. Since this is ${disc < 0 ? "negative" : disc === 0 ? "zero" : "positive"}, the PDE is ${type.toLowerCase()}.` };
    },
    function heatEquationExample() {
      const q = `The equation u_t = k·u_xx (k > 0) models which physical phenomenon?`;
      const ans = "Heat conduction / diffusion";
      const wrong = ["Wave propagation", "Steady-state potential", "Fluid vorticity transport", "Elastic beam bending"];
      return { key: `heateq`, q, ans, wrong, exp: `u_t = k u_xx is the standard 1-D heat (diffusion) equation.` };
    },
    function separationOfVariables() {
      const q = `In solving u_t = k·u_xx by separation of variables u(x,t) = X(x)T(t), the resulting ODE for X(x) with separation constant −λ is:`;
      const ans = "X'' + λX = 0";
      const wrong = ["X'' − λX = 0", "X' + λX = 0", "X'' + λX' = 0", "X'' = λ"];
      return { key: `sepvar`, q, ans, wrong, exp: `Substituting and dividing by XT gives T'/(kT) = X''/X = −λ, so X'' + λX = 0.` };
    },
    function waveEquationOrder() {
      const q = `The one-dimensional wave equation u_tt = c²u_xx is second order in time and:`;
      const ans = "second order in space";
      const wrong = ["first order in space", "third order in space", "zeroth order in space"];
      return { key: `wave-order`, q, ans, wrong, exp: `u_xx is a second-order spatial derivative, so the wave equation is second order in both t and x.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- PROBABILITY ---------- */
function genProbability(rng, difficulty) {
  function C(n, r) { if (r < 0 || r > n) return 0; let num = 1; for (let i = 0; i < r; i++) num *= (n - i); let den = 1; for (let i = 1; i <= r; i++) den *= i; return num / den; }
  const templates = [
    function binomialProb() {
      const n = rInt(rng, 4, 8), k = rInt(rng, 1, n - 1);
      const total = Math.pow(2, n);
      const favorable = C(n, k);
      const q = `A fair coin is tossed ${n} times. What is the probability of getting exactly ${k} heads? (Express as a fraction of 2^${n}.)`;
      const ans = fracStr(favorable, total);
      const wrong = [fracStr(C(n, k - 1) || 1, total), fracStr(C(n, k + 1) || 1, total), fracStr(favorable, total * 2), fracStr(favorable + 1, total)];
      return { key: `binom-${n}-${k}`, q, ans, wrong, exp: `P(X=k) = C(${n},${k})/2^${n} = ${favorable}/${total} = ${ans}.` };
    },
    function bayesTheorem() {
      const pA = rPick(rng, [0.3, 0.4, 0.5, 0.6]);
      const pBgivenA = rPick(rng, [0.7, 0.8, 0.9]);
      const pBgivenNotA = rPick(rng, [0.1, 0.2, 0.3]);
      const pB = pBgivenA * pA + pBgivenNotA * (1 - pA);
      const pAgivenB = (pBgivenA * pA) / pB;
      const ans = fmtNum(Math.round(pAgivenB * 1000) / 1000);
      const q = `P(A)=${pA}, P(B|A)=${pBgivenA}, P(B|A^c)=${pBgivenNotA}. Find P(A|B) using Bayes' theorem (round to 3 decimals).`;
      const wrong = [fmtNum(pA), fmtNum(pBgivenA), fmtNum(Math.round((1 - pAgivenB) * 1000) / 1000)];
      return { key: `bayes-${pA}-${pBgivenA}-${pBgivenNotA}`, q, ans, wrong, exp: `P(A|B) = P(B|A)P(A) / [P(B|A)P(A)+P(B|A^c)P(A^c)] = ${fmtNum(pBgivenA * pA)}/${fmtNum(pB)} ≈ ${ans}.` };
    },
    function expectationDiscrete() {
      const vals = [rInt(rng, 1, 3), rInt(rng, 4, 6), rInt(rng, 7, 9)];
      const p1 = 0.5, p2 = 0.3, p3 = 0.2;
      const E = vals[0] * p1 + vals[1] * p2 + vals[2] * p3;
      const q = `A discrete random variable X takes values ${vals[0]}, ${vals[1]}, ${vals[2]} with probabilities 0.5, 0.3, 0.2 respectively. Find E[X].`;
      const ans = fmtNum(Math.round(E * 100) / 100);
      const wrong = [fmtNum(Math.round((E + 0.5) * 100) / 100), fmtNum(Math.round((E - 0.5) * 100) / 100), fmtNum(vals[1])];
      return { key: `expect-${vals.join(",")}`, q, ans, wrong, exp: `E[X] = ${vals[0]}(0.5)+${vals[1]}(0.3)+${vals[2]}(0.2) = ${ans}.` };
    },
    function independentEvents() {
      const pA = rPick(rng, [0.2, 0.3, 0.4, 0.5]);
      const pB = rPick(rng, [0.3, 0.4, 0.5, 0.6]);
      const q = `If A and B are independent events with P(A)=${pA} and P(B)=${pB}, find P(A ∩ B).`;
      const ans = fmtNum(Math.round(pA * pB * 100) / 100);
      const wrong = [fmtNum(pA + pB), fmtNum(Math.round((pA + pB - pA * pB) * 100) / 100), fmtNum(pA)];
      return { key: `indep-${pA}-${pB}`, q, ans, wrong, exp: `For independent events, P(A∩B) = P(A)P(B) = ${pA}×${pB} = ${ans}.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- STATISTICS ---------- */
function genStatistics(rng, difficulty) {
  const templates = [
    function sampleMeanVariance() {
      const data = Array.from({ length: 5 }, () => rInt(rng, 1, 10));
      const mean = data.reduce((a, b) => a + b, 0) / data.length;
      const q = `Find the sample mean of the data set: {${data.join(", ")}}.`;
      const ans = fmtNum(Math.round(mean * 100) / 100);
      const wrong = [fmtNum(mean + 1), fmtNum(mean - 1), fmtNum(Math.round((mean + 0.5) * 100) / 100)];
      return { key: `mean-${data.join(",")}`, q, ans, wrong, exp: `Mean = (${data.join("+")})/${data.length} = ${ans}.` };
    },
    function mleExponential() {
      const data = Array.from({ length: 4 }, () => rInt(rng, 1, 6));
      const mean = data.reduce((a, b) => a + b, 0) / data.length;
      const mle = 1 / mean;
      const q = `For an Exponential(λ) distribution, the MLE of λ based on sample {${data.join(", ")}} is 1/x̄. Find the MLE (round to 3 decimals).`;
      const ans = fmtNum(Math.round(mle * 1000) / 1000);
      const wrong = [fmtNum(mean), fmtNum(Math.round((mle + 0.05) * 1000) / 1000), fmtNum(Math.round((mle - 0.05) * 1000) / 1000)];
      return { key: `mle-${data.join(",")}`, q, ans, wrong, exp: `x̄ = ${fmtNum(mean)}, so MLE λ̂ = 1/x̄ = ${ans}.` };
    },
    function correlationSign() {
      const q = `If cov(X,Y) < 0 and both var(X), var(Y) > 0, the correlation coefficient ρ(X,Y) is:`;
      const ans = "Negative";
      const wrong = ["Positive", "Zero", "Undefined"];
      return { key: `corrsign`, q, ans, wrong, exp: `ρ = cov(X,Y)/(σ_Xσ_Y). Since the denominator is positive and the numerator is negative, ρ < 0.` };
    },
    function unbiasedEstimator() {
      const q = `Which of the following is an unbiased estimator of the population variance σ² from a sample of size n?`;
      const ans = "Σ(xi−x̄)²/(n−1)";
      const wrong = ["Σ(xi−x̄)²/n", "Σ(xi−x̄)²/(n+1)", "Σxi²/n"];
      return { key: `unbiasedvar`, q, ans, wrong, exp: `The sample variance with denominator (n−1), not n, is the unbiased estimator of σ² — this correction is Bessel's correction.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- NUMERICAL ANALYSIS ---------- */
function genNumerical(rng, difficulty) {
  const templates = [
    function newtonRaphson() {
      const x0 = rInt(rng, 1, 3);
      // f(x) = x^2 - a, f'(x) = 2x
      const a = rInt(rng, 5, 20);
      const fx0 = x0 * x0 - a, fpx0 = 2 * x0;
      const x1 = x0 - fx0 / fpx0;
      const q = `Using Newton–Raphson on f(x) = x² − ${a} with x0 = ${x0}, find x1 (round to 3 decimals).`;
      const ans = fmtNum(Math.round(x1 * 1000) / 1000);
      const wrong = [fmtNum(Math.round((x1 + 0.2) * 1000) / 1000), fmtNum(Math.round((x1 - 0.2) * 1000) / 1000), fmtNum(x0)];
      return { key: `newton-${x0}-${a}`, q, ans, wrong, exp: `x1 = x0 − f(x0)/f'(x0) = ${x0} − (${fx0})/(${fpx0}) = ${ans}.` };
    },
    function trapezoidalRule() {
      // integrate f(x)=x on [a,b] with 1 interval — trapezoidal gives exact value here
      const a = rInt(rng, 0, 2), b = a + rInt(rng, 2, 4);
      const fa = a * a, fb = b * b; // f(x) = x^2 (trapezoidal approximates)
      const approx = (b - a) * (fa + fb) / 2;
      const q = `Using the trapezoidal rule with a single interval, approximate ∫[${a} to ${b}] x² dx.`;
      const ans = fmtNum(approx);
      const wrong = [fmtNum(approx + (b - a)), fmtNum(approx - (b - a)), fmtNum((b - a) * fa)];
      return { key: `trap-${a}-${b}`, q, ans, wrong, exp: `Trapezoidal estimate = (b−a)[f(a)+f(b)]/2 = (${b - a})[${fa}+${fb}]/2 = ${ans}.` };
    },
    function orderOfConvergence() {
      const q = `The Newton–Raphson method, when it converges to a simple root, has order of convergence:`;
      const ans = "2 (quadratic)";
      const wrong = ["1 (linear)", "3 (cubic)", "1.5 (superlinear)"];
      return { key: `nr-order`, q, ans, wrong, exp: `Newton–Raphson converges quadratically (order 2) near a simple root, assuming f is sufficiently smooth and f'(root)≠0.` };
    },
    function fixedPointIteration() {
      const q = `The fixed-point iteration x_{n+1} = g(x_n) converges locally near a fixed point x* if:`;
      const ans = "|g'(x*)| < 1";
      const wrong = ["|g'(x*)| > 1", "g'(x*) = 0 always required", "g(x*) < x*"];
      return { key: `fpi-condition`, q, ans, wrong, exp: `Local convergence of fixed-point iteration requires |g'(x*)| < 1 near the fixed point (contraction condition).` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- TOPOLOGY ---------- */
function genTopology(rng, difficulty) {
  const bank = [
    { q: "Every continuous image of a compact space is:", ans: "Compact", wrong: ["Connected only", "Discrete", "Open"], exp: "Continuous maps preserve compactness — the image of a compact set under a continuous map is compact." },
    { q: "In a metric space, every convergent sequence is:", ans: "Cauchy", wrong: ["Divergent", "Unbounded", "Discontinuous"], exp: "Convergent sequences in any metric space are always Cauchy sequences." },
    { q: "A metric space is compact if and only if it is:", ans: "Complete and totally bounded", wrong: ["Open and bounded", "Connected and closed", "Dense and bounded"], exp: "By a standard theorem, a metric space is compact iff it is complete and totally bounded." },
    { q: "The union of two connected sets sharing a common point is always:", ans: "Connected", wrong: ["Disconnected", "Compact", "Open"], exp: "If two connected sets share a point, their union is connected — a standard topology result." },
    { q: "A discrete topological space with more than one point is:", ans: "Not connected", wrong: ["Connected", "Compact (if infinite)", "Always finite"], exp: "In the discrete topology, every subset is both open and closed, so any space with ≥2 points splits into disjoint open sets — it is disconnected." },
    { q: "In ℝ with the usual topology, the set of rational numbers ℚ is:", ans: "Neither open nor closed", wrong: ["Open", "Closed", "Compact"], exp: "ℚ is dense in ℝ but its complement (irrationals) is also dense, so ℚ is neither open nor closed." }
  ];
  const t = rPick(rng, bank);
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: `topo-${t.q.slice(0, 20)}` };
}

/* ---------- FUNCTIONAL ANALYSIS ---------- */
function genFunctionalAnalysis(rng, difficulty) {
  const templates = [
    function multiplicationOperatorNorm() {
      const c = rInt(rng, 2, 9);
      const q = `Let T: L²[0,1] → L²[0,1] be the multiplication operator (Tf)(x) = ${c}·f(x). What is the operator norm ‖T‖?`;
      const wrong = [c + 1, c - 1, c * c, 1].map(String);
      return { key: `multop-${c}`, q, ans: String(c), wrong, exp: `For a multiplication operator by a constant c, ‖T‖ = |c| = ${c}, since ‖Tf‖=|c|‖f‖ for all f.` };
    }
  ];
  const bank = [
    { q: "Every Hilbert space is also a:", ans: "Banach space", wrong: ["Finite-dimensional space", "Discrete space", "Compact space"], exp: "A Hilbert space is a complete inner product space, and completeness w.r.t. the induced norm makes it a Banach space." },
    { q: "In a Hilbert space H, the Riesz Representation Theorem relates bounded linear functionals to:", ans: "Inner products with a unique vector", wrong: ["Eigenvalues of the identity", "Compact operators only", "Orthonormal bases only"], exp: "Riesz Representation: every bounded linear functional f on H has the form f(x)=⟨x,y⟩ for a unique y∈H." },
    { q: "A bounded linear operator between normed spaces is always:", ans: "Continuous", wrong: ["Compact", "Invertible", "Self-adjoint"], exp: "Boundedness of a linear operator is equivalent to continuity in normed spaces." },
    { q: "In an inner product space, the Cauchy–Schwarz inequality states |⟨x,y⟩| ≤:", ans: "‖x‖‖y‖", wrong: ["‖x‖+‖y‖", "‖x‖²+‖y‖²", "‖x−y‖"], exp: "Cauchy–Schwarz: |⟨x,y⟩| ≤ ‖x‖‖y‖, with equality iff x,y are linearly dependent." }
  ];
  if (rng() < 0.4) { const t = rPick(rng, templates)(); return t; }
  const t = rPick(rng, bank);
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: `fa-${t.q.slice(0, 20)}` };
}

/* ---------- NUMBER THEORY ---------- */
function genNumberTheory(rng, difficulty) {
  function extgcd(a, b) { if (b === 0) return [a, 1, 0]; const [g, x1, y1] = extgcd(b, a % b); return [g, y1, x1 - Math.floor(a / b) * y1]; }
  const templates = [
    function gcdCalc() {
      const a = rInt(rng, 10, 60), b = rInt(rng, 10, 60);
      const g = gcd(a, b);
      const q = `Find gcd(${a}, ${b}).`;
      const wrong = [g + 1, Math.max(1, g - 1), g * 2].map(String);
      return { key: `gcd-${a}-${b}`, q, ans: String(g), wrong, exp: `Using the Euclidean algorithm, gcd(${a},${b}) = ${g}.` };
    },
    function linearCongruence() {
      let a, n;
      do { a = rInt(rng, 2, 9); n = rPick(rng, [7, 11, 13]); } while (gcd(a, n) !== 1);
      const [, x] = extgcd(a, n);
      const inv = ((x % n) + n) % n;
      const b = rInt(rng, 1, n - 1);
      const sol = (inv * b) % n;
      const q = `Solve the linear congruence ${a}x ≡ ${b} (mod ${n}) for x, with 0 ≤ x < ${n}.`;
      const wrong = [(sol + 1) % n, (sol + 2) % n, Math.max(0, sol - 1)].map(String);
      return { key: `lincong-${a}-${b}-${n}`, q, ans: String(sol), wrong, exp: `Since gcd(${a},${n})=1, the inverse of ${a} mod ${n} is ${inv}. So x ≡ ${inv}×${b} ≡ ${sol} (mod ${n}).` };
    },
    function eulerPhiValue() {
      const n = rPick(rng, [9, 14, 15, 16, 21, 22, 25]);
      let phi = 0; for (let k = 1; k <= n; k++) if (gcd(k, n) === 1) phi++;
      const q = `Compute Euler's totient φ(${n}).`;
      const wrong = [phi + 1, Math.max(1, phi - 1), n - 1].map(String);
      return { key: `phi-${n}`, q, ans: String(phi), wrong, exp: `φ(${n}) counts integers in [1,${n}] coprime to ${n}, which is ${phi}.` };
    },
    function quadraticResidue() {
      const p = rPick(rng, [7, 11, 13]);
      const a = rInt(rng, 2, p - 1);
      let isQR = false;
      for (let x = 1; x < p; x++) if ((x * x) % p === a) { isQR = true; break; }
      const q = `Is ${a} a quadratic residue modulo the prime ${p}? (i.e., does x² ≡ ${a} (mod ${p}) have a solution?)`;
      const ans = isQR ? "Yes" : "No";
      const wrong = [isQR ? "No" : "Yes"];
      return { key: `qr-${p}-${a}`, q, ans, wrong, exp: `Checking all residues mod ${p}, ${a} ${isQR ? "does" : "does not"} appear as a square, so the answer is ${ans}.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- CALCULUS ---------- */
function genCalculus(rng, difficulty) {
  const templates = [
    function derivativePower() {
      const n = rInt(rng, 2, 6), c = rInt(rng, 2, 5);
      const q = `Find d/dx [${c}x^${n}] at x = 1.`;
      const val = c * n;
      const wrong = [val + 1, val - 1, c * (n - 1)].map(String);
      return { key: `deriv-${c}-${n}`, q, ans: String(val), wrong, exp: `d/dx[${c}x^${n}] = ${c}${n}x^${n - 1} = ${val}x^${n - 1}. At x=1, this equals ${val}.` };
    },
    function definiteIntegral() {
      const a = rInt(rng, 0, 2), b = a + rInt(rng, 1, 3);
      const val = (b * b * b - a * a * a) / 3;
      const q = `Evaluate ∫[${a} to ${b}] x² dx.`;
      const ans = fracStr(b * b * b - a * a * a, 3);
      const wrong = [fracStr(b * b - a * a, 2), fmtNum(val + 1), fmtNum(val - 1)];
      return { key: `integ-${a}-${b}`, q, ans, wrong, exp: `∫x²dx = x³/3, evaluated from ${a} to ${b} gives (${b}³−${a}³)/3 = ${ans}.` };
    },
    function limitLHopital() {
      const q = `Evaluate lim (x→0) sin(x)/x.`;
      const ans = "1";
      const wrong = ["0", "∞", "Does not exist"];
      return { key: `limit-sinx`, q, ans, wrong, exp: `This is the classic standard limit lim(x→0) sin(x)/x = 1.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- DISCRETE MATHEMATICS ---------- */
function genDiscrete(rng, difficulty) {
  function C(n, r) { if (r < 0 || r > n) return 0; let num = 1; for (let i = 0; i < r; i++) num *= (n - i); let den = 1; for (let i = 1; i <= r; i++) den *= i; return num / den; }
  const templates = [
    function combinations() {
      const n = rInt(rng, 6, 12), r = rInt(rng, 2, n - 2);
      const val = C(n, r);
      const q = `In how many ways can a committee of ${r} people be chosen from ${n} people?`;
      const wrong = [C(n, r - 1), C(n, r + 1), val + 1].map(String);
      return { key: `comb-${n}-${r}`, q, ans: String(val), wrong, exp: `The number of ways is C(${n},${r}) = ${val}.` };
    },
    function graphHandshake() {
      const n = rInt(rng, 4, 8);
      const sumDeg = 2 * (n - 1); // for a specific construction, just use total edges formula demo
      const edges = rInt(rng, n, (n * (n - 1)) / 2);
      const q = `A simple graph has ${edges} edges. What is the sum of the degrees of all its vertices?`;
      const ans = String(2 * edges);
      const wrong = [edges, edges + 1, edges * 3].map(String);
      return { key: `handshake-${edges}`, q, ans, wrong, exp: `By the Handshake Lemma, the sum of all vertex degrees equals 2×(number of edges) = 2×${edges} = ${2 * edges}.` };
    },
    function recurrenceRelation() {
      const q = `The recurrence relation a_n = a_{n-1} + a_{n-2}, with a_0=0, a_1=1, defines which famous sequence?`;
      const ans = "Fibonacci sequence";
      const wrong = ["Catalan numbers", "Lucas sequence (with these seeds)", "Geometric sequence"];
      return { key: `recur-fib`, q, ans, wrong, exp: `This exact recurrence with a_0=0, a_1=1 defines the Fibonacci sequence.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* ---------- PART A: APTITUDE ---------- */
function genAptitude(rng, difficulty) {
  const templates = [
    function percentage() {
      const base = rInt(rng, 200, 900);
      const pct = rPick(rng, [10, 15, 20, 25, 30, 40]);
      const val = base * pct / 100;
      const q = `What is ${pct}% of ${base}?`;
      const wrong = [val + pct, val - pct, val + base * 0.05].map(v => fmtNum(v));
      return { key: `pct-${base}-${pct}`, q, ans: fmtNum(val), wrong, exp: `${pct}% of ${base} = (${pct}/100)×${base} = ${val}.` };
    },
    function ratio() {
      const a = rInt(rng, 2, 6), b = rInt(rng, 2, 6), total = (a + b) * rInt(rng, 5, 15);
      const shareA = total * a / (a + b);
      const q = `Two quantities are in the ratio ${a}:${b}. If their sum is ${total}, find the larger quantity.`;
      const larger = Math.max(shareA, total - shareA);
      const wrong = [fmtNum(larger + 5), fmtNum(larger - 5), fmtNum(total / 2)];
      return { key: `ratio-${a}-${b}-${total}`, q, ans: fmtNum(larger), wrong, exp: `Parts are ${a}x and ${b}x with (${a}+${b})x=${total}, so x=${total / (a + b)}. Larger part = ${larger}.` };
    },
    function average() {
      const nums = Array.from({ length: 5 }, () => rInt(rng, 10, 90));
      const avg = nums.reduce((a, b) => a + b, 0) / nums.length;
      const q = `Find the average of: ${nums.join(", ")}.`;
      const wrong = [avg + 2, avg - 2, avg + 5].map(v => fmtNum(v));
      return { key: `avg-${nums.join(",")}`, q, ans: fmtNum(avg), wrong, exp: `Average = sum/count = ${nums.reduce((a, b) => a + b, 0)}/${nums.length} = ${fmtNum(avg)}.` };
    },
    function sequencePattern() {
      const start = rInt(rng, 2, 8), diff = rInt(rng, 2, 6);
      const seq = [start, start + diff, start + 2 * diff, start + 3 * diff];
      const next = start + 4 * diff;
      const q = `Find the next term: ${seq.join(", ")}, ?`;
      const wrong = [next + diff, next - 1, next + 1].map(String);
      return { key: `seq-${start}-${diff}`, q, ans: String(next), wrong, exp: `This is an arithmetic sequence with common difference ${diff}. Next term = ${seq[3]} + ${diff} = ${next}.` };
    },
    function simpleProbability() {
      const total = rPick(rng, [6, 8, 10, 12]);
      const favorable = rInt(rng, 1, total - 1);
      const q = `A bag has ${total} balls, of which ${favorable} are red. If one ball is drawn at random, what is the probability it is red?`;
      const ans = fracStr(favorable, total);
      const wrong = [fracStr(total - favorable, total), fracStr(favorable, total + 2), fracStr(favorable + 1, total)];
      return { key: `simpprob-${total}-${favorable}`, q, ans, wrong, exp: `P(red) = favorable/total = ${favorable}/${total} = ${ans}.` };
    },
    function areaRectangle() {
      const l = rInt(rng, 4, 15), w = rInt(rng, 3, 12);
      const q = `Find the area of a rectangle with length ${l} and width ${w}.`;
      const ans = String(l * w);
      const wrong = [String(2 * (l + w)), String(l * w + w), String(l * w - l)];
      return { key: `area-${l}-${w}`, q, ans, wrong, exp: `Area = length × width = ${l} × ${w} = ${l * w}.` };
    },
    function workRate() {
      const daysA = rInt(rng, 4, 12), daysB = daysA + rInt(rng, 2, 8);
      const rateA = 1 / daysA, rateB = 1 / daysB;
      const combined = 1 / (rateA + rateB);
      const q = `A can complete a job in ${daysA} days, B in ${daysB} days. Working together, how many days will they take? (round to 2 decimals)`;
      const ans = fmtNum(Math.round(combined * 100) / 100);
      const wrong = [fmtNum(daysA + daysB), fmtNum((daysA + daysB) / 2), fmtNum(Math.round((combined + 1) * 100) / 100)];
      return { key: `work-${daysA}-${daysB}`, q, ans, wrong, exp: `Combined rate = 1/${daysA} + 1/${daysB}. Time = 1/(combined rate) ≈ ${ans} days.` };
    }
  ];
  const t = rPick(rng, templates)();
  return { q: t.q, ans: t.ans, wrong: t.wrong, exp: t.exp, key: t.key };
}

/* --------------------------- GENERATOR REGISTRY --------------------------- */
const TOPIC_GENERATORS = {
  "Real Analysis": genRealAnalysis,
  "Linear Algebra": genLinearAlgebra,
  "Complex Analysis": genComplexAnalysis,
  "Abstract Algebra": genAbstractAlgebra,
  "ODE": genODE,
  "PDE": genPDE,
  "Probability": genProbability,
  "Statistics": genStatistics,
  "Numerical Analysis": genNumerical,
  "Topology": genTopology,
  "Functional Analysis": genFunctionalAnalysis,
  "Number Theory": genNumberTheory,
  "Calculus": genCalculus,
  "Discrete Mathematics": genDiscrete
};

function pickWeightedTopic(rng) {
  const total = Object.values(TOPIC_WEIGHTS).reduce((a, b) => a + b, 0);
  let r = rng() * total;
  for (const topic of TOPIC_LIST) {
    r -= TOPIC_WEIGHTS[topic];
    if (r <= 0) return topic;
  }
  return TOPIC_LIST[TOPIC_LIST.length - 1];
}

function pickDifficulty(rng, mix) {
  const r = rng();
  if (r < mix.easy) return "Easy";
  if (r < mix.easy + mix.moderate) return "Moderate";
  if (r < mix.easy + mix.moderate + mix.hard) return "Hard";
  return "Very Hard";
}

// Multiple-correct wrapper: builds a "select all that apply" question from a themed bank.
const MULTI_CORRECT_BANK = [
  {
    topic: "Real Analysis",
    q: "Which of the following statements are TRUE for a continuous function f:[a,b]→ℝ?",
    options: ["f is bounded on [a,b]", "f attains its maximum and minimum on [a,b]", "f is necessarily differentiable on (a,b)", "f is uniformly continuous on [a,b]"],
    correct: [0, 1, 3],
    exp: "By the Extreme Value Theorem, a continuous function on a closed bounded interval is bounded and attains its extrema, and it is uniformly continuous (Heine–Cantor). Continuity does not imply differentiability."
  },
  {
    topic: "Linear Algebra",
    q: "Let A be an n×n matrix. Which of the following are TRUE?",
    options: ["If A is invertible, det(A) ≠ 0", "Eigenvalues of a triangular matrix are its diagonal entries", "Every square matrix is diagonalizable", "Similar matrices have the same eigenvalues"],
    correct: [0, 1, 3],
    exp: "Invertibility ⇔ nonzero determinant. Triangular matrices have diagonal entries as eigenvalues. Similar matrices share eigenvalues. Not every matrix is diagonalizable (e.g. nontrivial Jordan blocks)."
  },
  {
    topic: "Abstract Algebra",
    q: "Which of the following are TRUE about a finite group G?",
    options: ["The order of every element divides |G|", "G is always abelian", "Every subgroup's order divides |G| (Lagrange)", "G always has a subgroup of every order dividing |G|"],
    correct: [0, 2],
    exp: "By Lagrange, element orders and subgroup orders divide |G|. Finite groups need not be abelian, and the converse of Lagrange's theorem is false in general (e.g. A4 has no subgroup of order 6)."
  },
  {
    topic: "Complex Analysis",
    q: "Which of the following are TRUE for an analytic function f on a domain D?",
    options: ["f satisfies the Cauchy–Riemann equations", "f is infinitely differentiable on D", "f can be represented by a Taylor series locally", "f must be a polynomial"],
    correct: [0, 1, 2],
    exp: "Analytic functions satisfy CR equations, are infinitely differentiable, and are locally represented by convergent Taylor series. They need not be polynomials (e.g. e^z)."
  },
  {
    topic: "Topology",
    q: "Which of the following are TRUE in a general metric space?",
    options: ["Every compact set is closed and bounded", "Every closed and bounded set is compact", "Every convergent sequence is Cauchy", "Every Cauchy sequence converges"],
    correct: [0, 2],
    exp: "Compact ⇒ closed & bounded always, but the converse (Heine–Borel) holds only in ℝⁿ, not general metric spaces. Convergent ⇒ Cauchy always, but Cauchy ⇒ convergent only in complete spaces."
  },
  {
    topic: "Probability",
    q: "Which of the following are TRUE for any two events A, B in a probability space?",
    options: ["P(A ∪ B) = P(A) + P(B) − P(A ∩ B)", "If A, B are independent, P(A∩B)=P(A)P(B)", "If A, B are mutually exclusive, they are also independent (if both nonzero probability)", "P(A|B)P(B) = P(A∩B)"],
    correct: [0, 1, 3],
    exp: "Inclusion-exclusion and independence formulas are standard. Mutually exclusive events with positive probability are NOT independent (occurrence of one rules out the other)."
  }
];

function generateMultiCorrectQuestion(rng, part) {
  const item = rPick(rng, MULTI_CORRECT_BANK);
  const key = fp(item.topic, "multi-" + item.q.slice(0, 25));
  return {
    topic: item.topic,
    question: item.q,
    options: item.options,
    correct: item.correct.slice(),
    multiple: true,
    explanation: item.exp,
    fpKey: key
  };
}

/* --------------------------- QUESTION ASSEMBLY --------------------------- */
// Removes duplicates and anything equal to the correct answer from a wrong-option pool.
function cleanWrongPool(ans, wrongPool) {
  const ansStr = String(ans);
  const seen = new Set([ansStr]);
  const cleaned = [];
  for (const w of wrongPool) {
    const s = String(w);
    if (seen.has(s)) continue;
    seen.add(s);
    cleaned.push(s);
  }
  return cleaned;
}

function tryGenerateTopicQuestion(rng, topic, difficulty) {
  const gen = TOPIC_GENERATORS[topic];
  for (let attempt = 0; attempt < 8; attempt++) {
    const raw = gen(rng, difficulty);
    const key = fp(topic, raw.key);
    if (usedFingerprints.has(key)) continue;
    // Validate: dedupe wrong options and ensure at least 3 distinct wrong options remain
    const cleaned = cleanWrongPool(raw.ans, raw.wrong);
    if (cleaned.length < 3) continue; // not enough distinct distractors -> discard, try another
    usedFingerprints.add(key);
    const wrongs = shuffle(rng, cleaned).slice(0, 3);
    const allOptions = shuffle(rng, [String(raw.ans), ...wrongs]);
    return {
      topic,
      difficulty,
      question: raw.q,
      options: allOptions,
      correct: [allOptions.indexOf(String(raw.ans))],
      multiple: false,
      explanation: raw.exp,
      fpKey: key
    };
  }
  return null; // could not produce a fresh valid question after retries
}

function generatePartAQuestions(rng, mix) {
  const qs = [];
  let guard = 0;
  while (qs.length < PART_CONFIG.A.count && guard < 500) {
    guard++;
    const difficulty = (function () {
      const r = rng();
      if (r < 0.35) return "Easy";
      if (r < 0.90) return "Moderate";
      return "Hard";
    })();
    const raw = genAptitude(rng, difficulty);
    const key = fp("Aptitude", raw.key);
    if (usedFingerprints.has(key)) continue;
    const cleaned = cleanWrongPool(raw.ans, raw.wrong);
    if (cleaned.length < 3) continue;
    usedFingerprints.add(key);
    const wrongs = shuffle(rng, cleaned).slice(0, 3);
    const allOptions = shuffle(rng, [String(raw.ans), ...wrongs]);
    qs.push({
      topic: "Aptitude", difficulty, question: raw.q, options: allOptions,
      correct: [allOptions.indexOf(String(raw.ans))], multiple: false, explanation: raw.exp, fpKey: key
    });
  }
  return qs;
}

function generateMathQuestions(rng, count, mix, multiFraction) {
  const qs = [];
  let guard = 0;
  while (qs.length < count && guard < 3000) {
    guard++;
    const topic = pickWeightedTopic(rng);
    const difficulty = pickDifficulty(rng, mix);
    if (rng() < multiFraction) {
      const mq = generateMultiCorrectQuestion(rng, "B");
      if (usedFingerprints.has(mq.fpKey)) continue;
      usedFingerprints.add(mq.fpKey);
      mq.difficulty = difficulty;
      qs.push(mq);
      continue;
    }
    const q = tryGenerateTopicQuestion(rng, topic, difficulty);
    if (q) qs.push(q);
  }
  return qs;
}

function generateTest(testNum, attemptSalt) {
  const meta = TEST_META[testNum - 1];
  const seed = meta.seedBase * 97 + (attemptSalt || 0) * 7919;
  const rng = makeRNG(seed);

  const partA = generatePartAQuestions(rng, meta.mix);
  const partB = generateMathQuestions(rng, PART_CONFIG.B.count, meta.mix, 0.12);
  const partC = generateMathQuestions(rng, PART_CONFIG.C.count, {
    easy: 0, moderate: 0.12, hard: 0.43, veryhard: 0.45
  }, 0.15);

  saveFingerprints(usedFingerprints);

  return {
    testNum,
    label: meta.label,
    difficultyTag: meta.difficultyTag,
    generatedAt: Date.now(),
    parts: { A: partA, B: partB, C: partC }
  };
}

/* =========================================================================
   APP STATE & STORAGE
   ========================================================================= */
function testKey(n) { return `scorebooster_test_${n}`; }
function historyKey(n) { return `scorebooster_history_${n}`; }

function loadState(n) {
  try { return JSON.parse(localStorage.getItem(testKey(n))); } catch (e) { return null; }
}
function saveState(n, state) {
  localStorage.setItem(testKey(n), JSON.stringify(state));
}
function clearState(n) {
  localStorage.removeItem(testKey(n));
}
function loadHistory(n) {
  try { return JSON.parse(localStorage.getItem(historyKey(n))) || { attempts: 0, best: null, last: null }; }
  catch (e) { return { attempts: 0, best: null, last: null }; }
}
function saveHistory(n, h) {
  localStorage.setItem(historyKey(n), JSON.stringify(h));
}

let currentState = null; // active in-progress test state
let timerInterval = null;

/* --------------------------- VIEW SWITCHING --------------------------- */
function showView(id) {
  document.querySelectorAll(".view").forEach(v => v.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
  window.scrollTo(0, 0);
}

/* --------------------------- HOME RENDER --------------------------- */
function renderHome() {
  const grid = document.getElementById("test-cards");
  grid.innerHTML = "";
  TEST_META.forEach(meta => {
    const h = loadHistory(meta.id);
    const inProgress = !!loadState(meta.id);
    const card = document.createElement("div");
    card.className = "test-card";
    const diffClass = "diff-" + meta.difficultyTag.replace(/\+/g, "_").replace(/\s+/g, "_");
    card.innerHTML = `
      <span class="diff-badge ${diffClass}">${meta.difficultyTag}</span>
      <h3>${meta.label}</h3>
      <div class="card-meta">120 Questions &middot; 200 Marks &middot; 180 Minutes</div>
      ${h.attempts > 0 ? `<div class="card-history">Attempts: ${h.attempts} &middot; Best: ${fmtNum(h.best)} / 200 &middot; Last: ${fmtNum(h.last)} / 200</div>` : ""}
      <button class="btn btn-primary" data-test="${meta.id}">${inProgress ? "RESUME TEST" : "START TEST"}</button>
    `;
    card.querySelector("button").addEventListener("click", () => goToInstructions(meta.id));
    grid.appendChild(card);
  });

  const hgrid = document.getElementById("history-grid");
  hgrid.innerHTML = "";
  TEST_META.forEach(meta => {
    const h = loadHistory(meta.id);
    const div = document.createElement("div");
    div.className = "history-card";
    div.innerHTML = `<b>${meta.label}</b>
      Attempts: ${h.attempts}<br>
      Best Score: ${h.best !== null ? fmtNum(h.best) + " / 200" : "—"}<br>
      Last Score: ${h.last !== null ? fmtNum(h.last) + " / 200" : "—"}`;
    hgrid.appendChild(div);
  });
}

let pendingTestId = null;
function goToInstructions(testId) {
  pendingTestId = testId;
  const meta = TEST_META[testId - 1];
  document.getElementById("instr-test-name").textContent = meta.label + " — " + meta.difficultyTag;
  const existing = loadState(testId);
  document.getElementById("btn-start-test").textContent = existing ? "RESUME TEST" : "I AM READY — START TEST";
  showView("view-instructions");
}

document.getElementById("btn-back-home-1").addEventListener("click", () => { renderHome(); showView("view-home"); });
document.getElementById("btn-back-home-2").addEventListener("click", () => { renderHome(); showView("view-home"); });

document.getElementById("btn-start-test").addEventListener("click", () => {
  const testId = pendingTestId;
  let state = loadState(testId);
  if (!state) {
    const h = loadHistory(testId);
    const test = generateTest(testId, h.attempts);
    state = {
      testId,
      test,
      answers: {}, // qGlobalIndex(part-i) -> [selected option indices]
      marked: {},
      visited: {},
      currentPart: "A",
      currentIndex: 0,
      remainingSeconds: TEST_DURATION_SEC,
      startedAt: Date.now()
    };
    saveState(testId, state);
  }
  currentState = state;
  enterTestScreen();
});

/* --------------------------- TEST SCREEN --------------------------- */
function qid(part, idx) { return part + "-" + idx; }

function enterTestScreen() {
  showView("view-test");
  document.getElementById("testbar-sub").textContent = currentState.test.label;
  renderQuestion();
  startTimer();
}

function startTimer() {
  if (timerInterval) clearInterval(timerInterval);
  updateTimerDisplay();
  timerInterval = setInterval(() => {
    currentState.remainingSeconds--;
    if (currentState.remainingSeconds <= 0) {
      currentState.remainingSeconds = 0;
      updateTimerDisplay();
      clearInterval(timerInterval);
      submitTest(true);
      return;
    }
    updateTimerDisplay();
    if (currentState.remainingSeconds % 5 === 0) saveState(currentState.testId, currentState);
  }, 1000);
}

function updateTimerDisplay() {
  const s = currentState.remainingSeconds;
  const hh = String(Math.floor(s / 3600)).padStart(2, "0");
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  const el = document.getElementById("timer");
  el.textContent = `${hh}:${mm}:${ss}`;
  el.classList.remove("warn", "danger");
  if (s <= 300) el.classList.add("danger");
  else if (s <= 600) el.classList.add("danger");
  else if (s <= 1800) el.classList.add("warn");
}

function currentQuestion() {
  const part = currentState.currentPart;
  const idx = currentState.currentIndex;
  return currentState.test.parts[part][idx];
}

function attemptedCountInPart(part) {
  const qs = currentState.test.parts[part];
  let count = 0;
  for (let i = 0; i < qs.length; i++) {
    const ans = currentState.answers[qid(part, i)];
    if (ans && ans.length > 0) count++;
  }
  return count;
}

function renderQuestion() {
  const part = currentState.currentPart;
  const idx = currentState.currentIndex;
  const q = currentQuestion();
  const vId = qid(part, idx);
  currentState.visited[vId] = true;

  document.getElementById("part-indicator").textContent = "PART " + part;
  document.getElementById("q-number").textContent = `Part ${part} — Question ${idx + 1} of ${currentState.test.parts[part].length}`;
  const badge = document.getElementById("q-type-badge");
  badge.textContent = q.multiple ? "MULTIPLE CORRECT" : "SINGLE CORRECT";
  badge.className = "badge" + (q.multiple ? " multi" : "");
  const cfg = PART_CONFIG[part];
  document.getElementById("q-marks").textContent = cfg.negative ? `+${cfg.correct} / −${cfg.wrong}` : `+${cfg.correct} / 0`;
  document.getElementById("q-text").textContent = q.question;

  const optsDiv = document.getElementById("q-options");
  optsDiv.innerHTML = "";
  const selected = currentState.answers[vId] || [];
  q.options.forEach((opt, i) => {
    const row = document.createElement("label");
    row.className = "option" + (selected.includes(i) ? " selected" : "");
    const input = document.createElement("input");
    input.type = q.multiple ? "checkbox" : "radio";
    input.name = "opt";
    input.checked = selected.includes(i);
    input.addEventListener("change", () => onOptionSelect(i, q.multiple));
    const label = document.createElement("span");
    label.className = "option-label";
    label.textContent = String.fromCharCode(65 + i) + ".";
    const text = document.createElement("span");
    text.textContent = opt;
    row.appendChild(input); row.appendChild(label); row.appendChild(text);
    optsDiv.appendChild(row);
  });

  renderAttemptCounts();
  renderPalette();
  document.getElementById("btn-prev").disabled = (idx === 0);
  saveState(currentState.testId, currentState);
}

function onOptionSelect(i, multiple) {
  const part = currentState.currentPart, idx = currentState.currentIndex;
  const vId = qid(part, idx);
  let selected = currentState.answers[vId] || [];
  const alreadyAnswered = selected.length > 0;

  if (!alreadyAnswered) {
    const attempted = attemptedCountInPart(part);
    if (attempted >= PART_CONFIG[part].maxAttempt) {
      alert(`You have reached the maximum evaluated attempts for Part ${part} (${PART_CONFIG[part].maxAttempt}). Clear a response in another question first.`);
      renderQuestion();
      return;
    }
  }

  if (multiple) {
    if (selected.includes(i)) selected = selected.filter(x => x !== i);
    else selected = [...selected, i];
  } else {
    selected = [i];
  }
  currentState.answers[vId] = selected;
  renderQuestion();
}

function renderAttemptCounts() {
  const div = document.getElementById("attempt-counts");
  div.innerHTML = "";
  ["A", "B", "C"].forEach(p => {
    const attempted = attemptedCountInPart(p);
    const max = PART_CONFIG[p].maxAttempt;
    const span = document.createElement("span");
    span.innerHTML = `Part ${p} Attempted: <b class="${attempted >= max ? 'limit' : ''}">${attempted} / ${max}</b>`;
    div.appendChild(span);
  });
}

function paletteStatus(part, idx) {
  const vId = qid(part, idx);
  const answered = (currentState.answers[vId] || []).length > 0;
  const marked = !!currentState.marked[vId];
  const visited = !!currentState.visited[vId];
  if (marked && answered) return "markedanswered";
  if (marked) return "marked";
  if (answered) return "answered";
  if (visited) return "notanswered";
  return "notvisited";
}

function renderPalette() {
  const part = currentState.currentPart;
  document.getElementById("palette-part-label").textContent = "PART " + part;
  const grid = document.getElementById("palette-grid");
  grid.innerHTML = "";
  currentState.test.parts[part].forEach((q, i) => {
    const btn = document.createElement("button");
    const status = paletteStatus(part, i);
    btn.className = "pnum " + status + (i === currentState.currentIndex ? " current" : "");
    btn.textContent = i + 1;
    btn.addEventListener("click", () => { currentState.currentIndex = i; renderQuestion(); });
    grid.appendChild(btn);
  });
}

document.getElementById("btn-palette-toggle").addEventListener("click", () => {
  document.getElementById("palette-panel").classList.toggle("open");
});

document.getElementById("btn-clear").addEventListener("click", () => {
  const vId = qid(currentState.currentPart, currentState.currentIndex);
  delete currentState.answers[vId];
  renderQuestion();
});

document.getElementById("btn-mark").addEventListener("click", () => {
  const vId = qid(currentState.currentPart, currentState.currentIndex);
  currentState.marked[vId] = true;
  goNext();
});

document.getElementById("btn-next").addEventListener("click", () => goNext());
document.getElementById("btn-prev").addEventListener("click", () => {
  if (currentState.currentIndex > 0) { currentState.currentIndex--; renderQuestion(); }
});

function goNext() {
  const part = currentState.currentPart;
  const qs = currentState.test.parts[part];
  if (currentState.currentIndex < qs.length - 1) {
    currentState.currentIndex++;
  } else {
    const order = ["A", "B", "C"];
    const pi = order.indexOf(part);
    if (pi < order.length - 1) {
      currentState.currentPart = order[pi + 1];
      currentState.currentIndex = 0;
    }
  }
  renderQuestion();
}

document.getElementById("btn-submit-test").addEventListener("click", () => {
  if (confirm("Submit the test now? You will not be able to change your answers after submitting.")) {
    submitTest(false);
  }
});

/* --------------------------- SCORING --------------------------- */
function scoreTest(state) {
  const perPart = {};
  const topicStats = {};
  const reviewItems = [];

  ["A", "B", "C"].forEach(part => {
    const cfg = PART_CONFIG[part];
    const qs = state.test.parts[part];
    let correct = 0, wrong = 0, unanswered = 0, marks = 0;
    qs.forEach((q, i) => {
      const vId = qid(part, i);
      const selected = state.answers[vId] || [];
      let status;
      if (selected.length === 0) {
        status = "unanswered"; unanswered++;
      } else {
        const correctSet = q.correct.slice().sort().join(",");
        const selSet = selected.slice().sort().join(",");
        const isCorrect = correctSet === selSet;
        if (isCorrect) { status = "correct"; correct++; marks += cfg.correct; }
        else { status = "incorrect"; wrong++; if (cfg.negative) marks += cfg.wrong; }
      }
      if (!topicStats[q.topic]) topicStats[q.topic] = { correct: 0, total: 0 };
      topicStats[q.topic].total++;
      if (status === "correct") topicStats[q.topic].correct++;

      reviewItems.push({
        part, index: i, topic: q.topic, difficulty: q.difficulty || "-",
        question: q.question, options: q.options, correctIdx: q.correct,
        selected, status, explanation: q.explanation, multiple: q.multiple
      });
    });
    perPart[part] = { correct, wrong, unanswered, marks, attempted: correct + wrong };
  });

  const totalMarks = perPart.A.marks + perPart.B.marks + perPart.C.marks;
  const totalAttempted = perPart.A.attempted + perPart.B.attempted + perPart.C.attempted;
  const totalCorrect = perPart.A.correct + perPart.B.correct + perPart.C.correct;
  const totalWrong = perPart.A.wrong + perPart.B.wrong + perPart.C.wrong;
  const totalUnanswered = perPart.A.unanswered + perPart.B.unanswered + perPart.C.unanswered;
  const accuracy = totalAttempted > 0 ? (totalCorrect / totalAttempted) * 100 : 0;

  return {
    perPart, topicStats, reviewItems, totalMarks, totalAttempted,
    totalCorrect, totalWrong, totalUnanswered, accuracy,
    timeUsedSec: TEST_DURATION_SEC - state.remainingSeconds
  };
}

let lastResult = null;

function submitTest(auto) {
  if (timerInterval) clearInterval(timerInterval);
  const result = scoreTest(currentState);
  lastResult = { state: currentState, result };

  const h = loadHistory(currentState.testId);
  h.attempts += 1;
  h.last = result.totalMarks;
  h.best = h.best === null ? result.totalMarks : Math.max(h.best, result.totalMarks);
  saveHistory(currentState.testId, h);

  clearState(currentState.testId);
  renderResult(auto);
  showView("view-result");
}

/* --------------------------- RESULT RENDER --------------------------- */
function renderResult(auto) {
  const { state, result } = lastResult;
  document.getElementById("result-test-name").textContent = state.test.label + (auto ? " (Auto-submitted)" : "");
  document.getElementById("result-score").textContent = fmtNum(result.totalMarks);
  document.getElementById("result-pct").textContent = fmtNum(Math.round((result.totalMarks / 200) * 1000) / 10);

  const statGrid = document.getElementById("result-stat-grid");
  const mins = Math.floor(result.timeUsedSec / 60);
  statGrid.innerHTML = [
    ["Attempted", result.totalAttempted], ["Correct", result.totalCorrect],
    ["Incorrect", result.totalWrong], ["Unanswered", result.totalUnanswered],
    ["Accuracy", fmtNum(Math.round(result.accuracy * 10) / 10) + "%"], ["Time Used", mins + " min"]
  ].map(([label, val]) => `<div class="stat-box"><b>${val}</b><span>${label}</span></div>`).join("");

  const partGrid = document.getElementById("part-score-grid");
  partGrid.innerHTML = ["A", "B", "C"].map(p => {
    const pr = result.perPart[p];
    return `<div class="part-score-card"><b>${fmtNum(pr.marks)}</b>PART ${p}<br><span style="font-size:11px;color:var(--text-faint)">${pr.correct}✓ / ${pr.wrong}✗ / ${pr.unanswered}–</span></div>`;
  }).join("");

  const topicGrid = document.getElementById("topic-analysis-grid");
  const topics = Object.keys(result.topicStats).sort();
  topicGrid.innerHTML = topics.map(t => {
    const s = result.topicStats[t];
    const pct = s.total > 0 ? (s.correct / s.total) * 100 : 0;
    return `<div class="topic-row">
      <span>${t}</span>
      <span class="topic-bar-bg"><span class="topic-bar-fill" style="width:${pct}%"></span></span>
      <span>${s.correct}/${s.total}</span>
    </div>`;
  }).join("");
}

document.getElementById("btn-review").addEventListener("click", () => { renderReview(); showView("view-review"); });
document.getElementById("btn-back-result").addEventListener("click", () => showView("view-result"));

document.getElementById("btn-retake").addEventListener("click", () => {
  const testId = lastResult.state.testId;
  clearState(testId);
  goToInstructions(testId);
});

/* --------------------------- REVIEW RENDER --------------------------- */
function renderReview() {
  const { result } = lastResult;
  const list = document.getElementById("review-list");
  list.innerHTML = "";
  result.reviewItems.forEach((item, n) => {
    const div = document.createElement("div");
    div.className = "review-item " + item.status;
    const yourAns = item.selected.length ? item.selected.map(i => String.fromCharCode(65 + i) + ". " + item.options[i]).join("; ") : "Not answered";
    const correctAns = item.correctIdx.map(i => String.fromCharCode(65 + i) + ". " + item.options[i]).join("; ");
    div.innerHTML = `
      <div class="review-tags">
        <span class="tag">PART ${item.part}</span>
        <span class="tag">${item.topic}</span>
        <span class="tag">${item.difficulty}</span>
        <span class="tag">${item.multiple ? "MULTIPLE CORRECT" : "SINGLE CORRECT"}</span>
        <span class="tag">${item.status.toUpperCase()}</span>
      </div>
      <div class="review-q"><b>Q${n + 1}.</b> ${item.question}</div>
      <div class="review-ans-row"><b>Your Answer:</b> ${yourAns}</div>
      <div class="review-ans-row"><b>Correct Answer:</b> ${correctAns}</div>
      <div class="review-explain">${item.explanation}</div>
    `;
    list.appendChild(div);
  });
}

/* --------------------------- INIT --------------------------- */
function init() {
  renderHome();
  showView("view-home");
}
init();
