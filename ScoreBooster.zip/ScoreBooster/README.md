# ScoreBooster — CSIR-NET Mathematical Sciences Mock Tests

A frontend-only, full-length CSIR-NET Mathematical Sciences mock test
platform. Pure HTML/CSS/vanilla JavaScript — no build step, no backend,
no dependencies.

## Run it

Just open `index.html` in a browser. That's it.

## Deploy to GitHub Pages

1. Push this folder's contents to the root of a GitHub repository
   (`index.html` must sit at the repo root, not inside a subfolder).
2. In the repo, go to **Settings → Pages**, set the source to the
   `main` branch, root folder.
3. Your site will be live at `https://<username>.github.io/<repo>/`.

No `npm install`, no build command, no `dist` folder required.

## How it works

- **Five full-length mock tests**, each with Part A (20 general
  aptitude questions), Part B (40 questions), and Part C (60 questions)
  — 120 questions / 200 marks / 180 minutes per test, following the
  CSIR-NET Mathematical Sciences marking scheme (Part A: +2/−0.5,
  Part B: +3/−0.75, Part C: +4.75/no negative marking).
- Questions are produced by a **programmatic generator** (`app.js`):
  each subject (Real Analysis, Linear Algebra, Complex Analysis,
  Abstract Algebra, ODE, PDE, Probability, Statistics, Numerical
  Analysis, Topology, Functional Analysis, Number Theory, Calculus,
  Discrete Mathematics) has template functions that randomize
  numeric parameters and **compute the correct answer at runtime**
  (determinants, eigenvalues, residues, probabilities, MLEs, Newton–
  Raphson steps, etc.) rather than using a fixed static question bank.
- Every generated question is validated before use: distractor
  options are de-duplicated and checked against the computed answer,
  and a fingerprint (topic + template + parameters) is recorded so
  the same question is never repeated across tests or retakes.
- Topic weighting for Part B + Part C follows the priority order in
  the brief (Real Analysis / Linear Algebra / Complex Analysis /
  Abstract Algebra highest, then ODE/PDE/Probability/Statistics/
  Numerical Analysis, then Topology/Functional Analysis/Number Theory/
  Calculus/Discrete Mathematics) — these are mock-test weighting
  choices, not official NTA-published percentages.
- The five tests scale in difficulty (Standard → Advanced) by shifting
  the easy/moderate/hard/very-hard mix used during generation.
- Full CBT-style flow: Home → Instructions → Timed test screen with a
  question palette (Not Visited / Not Answered / Answered / Marked /
  Marked+Answered), attempt-limit warnings per part, auto-submit at
  00:00:00 → Result → Topic-wise analysis → Answer review → Retake
  (generates a fresh randomized paper) or return to the dashboard.
- Progress, answers, timer state, and test history are all stored in
  the browser's `localStorage` (keys `scorebooster_test_1..5` for
  in-progress attempts, `scorebooster_history_1..5` for past scores).
  Nothing is sent anywhere — everything runs client-side.

## Known limitations

- The question generator covers the syllabus broadly with parameterized
  templates per topic rather than an exhaustive hand-written bank —
  some lower-weighted topics (e.g. Topology, PDE, Functional Analysis)
  have fewer distinct templates, so their exact share of a given paper
  may drift from the target percentage range, especially on retakes
  once many fingerprint combinations have been used.
- "Attempt limit" evaluation is enforced at answer-time (you're blocked
  from exceeding the max attempts per part), matching the spirit of the
  CSIR-NET evaluation rule; this is a simplification of NTA's own
  tie-breaking procedure for over-attempted parts.
